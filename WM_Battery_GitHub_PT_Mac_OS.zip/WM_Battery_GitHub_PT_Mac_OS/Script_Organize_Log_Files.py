#Importa as bibliotecas que são utilizadas neste script
import pandas as pd
import os

#Guarda o path onde estão guardados os ficheiros com os dados experimentais dos participantes
part_data_path = os.getcwd() + "\data_participants"

#Esta função cria uma lista com os nomes de todos os ficheiros que estão no diretório contido na variável part_data_path.
#No fundo, esta função cria uma lista com os nomes dos ficheiros que contêm os dados experimentais dos participantes.
list_of_files = os.listdir(part_data_path)

#Acrescenta a raíz 'data_participants' à lista que contém os nomes dos ficheiros que contêm os dados dos participantes.
full_path_files = []
for i in range(0,len(list_of_files)):
    create_str_file = 'data_participants/' + list_of_files[i]
    full_path_files.append(create_str_file)

#Cria uma Dataframe com os dados de todos os participantes utilizando o métodos 'read_csv' para criar uma DataFrame para os dados
#de cada participante, e depois unindo estas DataFrames através do método append().
df_total_part = pd.DataFrame()
for i in range(0, len(full_path_files)):
    df = pd.read_csv(full_path_files[i],error_bad_lines=False)
    df_total_part = df_total_part.append(df)


#Substitui dados que deviam estar listados como missing values ('undefined'), por missing values ('Nan')
df_total_part = df_total_part.replace('undefined','Nan')

#Puxa a coluna com o nome da tarefa que foi realizado neste ensaio e número do participante para a primeira e
#segunda coluna respetivamente.
first_column = df_total_part.pop('Task_Name')
second_column = df_total_part.pop('subject_nr')
df_total_part.insert(0, 'Task_Name', first_column)
df_total_part.insert(1, 'subject_nr', second_column)

#Os seguintes 7 blocos de código criam 7 DataFrames distintas.
#Cada uma das DataFrames vai conter a informação referente a cada uma das sete tarefas de memória de trabalho (reading span, symmetry
# span, n-back task, multimodal span, operation span, binding task e Updating Task) realizadas por todos os participantes.

df_Reading_Span = df_total_part[df_total_part['Task_Name'] == 'Reading Span']
#print(df_Reading_Span)

df_N_Back = df_total_part[df_total_part['Task_Name'] == 'N-Back Task']
#print(df_N_Back)

df_WMU_Task = df_total_part[df_total_part['Task_Name'] == 'Working Memory Updating Task']
#print(df_WMU_Task)

df_Binding_Task = df_total_part[df_total_part['Task_Name'] == 'Binding Task']
#print(df_Binding_Task)

df_Operation_Span = df_total_part[df_total_part['Task_Name'] == 'Operation Span']
#print(df_Operation_Span)

df_Multimodal_Span = df_total_part[df_total_part['Task_Name'] == 'Multimodal Span']
#print(df_Multimodal_Span)

df_Symmetry_Span = df_total_part[df_total_part['Task_Name'] == 'Symmetry Span']
#print(df_Symmetry_Span)

#Os próximos 7 blocos de código selecionam as colunas com informação relevante de cada WM task e guardam estas colunas em DataFrames
#que só contêm informação relacionada com a mesma tarefa. Para além disso, estes nestes 7 blocos de código, são realizadas algumas
#conversões no formato dos dados (e.g., string to float) e são alterados os nomes de algumas colunas de forma a ficarem mais percétiveis.
if "Sim" in df_total_part['selRS'].values:
    if df_Reading_Span.iloc[0]['selSocDem'] == "Sim":
        df_Reading_Span = df_Reading_Span[['subject_nr','idade','genero','nacionalidade','freqEnsSup','HabEstudante','HabNaoEstudante','AnosEscolaridade','DoencasAnteriores','ListaDoencasAnteriores','CB_ref', 'CB_ref_process','practice','TrialNumber', 'subblock', 'SubTaskName', 'acc', 'avg_rt', 'BlockChoice', 'correct', 'correct_response', 'Frase', 'height', 'letter', 'List_Prev_Letter', 'List_responses_memory', 'live_row', 'logfile', 'response_average_time_memory', 'response_memory', 'response_processing', 'response_time_memory', 'response_time_processing', 'response_total_time_memory', 'RP_part_process_time', 'score_practice', 'score_reading_span', 'score_subblock_2_1', 'score_subblock_2_2', 'score_subblock_2_3', 'score_subblock_3_1', 'score_subblock_3_2', 'score_subblock_3_3', 'score_subblock_4_1', 'score_subblock_4_2', 'score_subblock_4_3', 'score_subblock_5_1', 'score_subblock_5_2', 'score_subblock_5_3', 'score_subblock_6_1', 'score_subblock_6_2', 'score_subblock_6_3', 'Sub_bloco', 'Tipo', 'total_correct', 'total_response_time', 'total_responses', 'width']]
        df_Reading_Span[['acc','avg_rt']] = df_Reading_Span[['acc','avg_rt']].replace(',','.')
        df_Reading_Span = df_Reading_Span.astype({'acc': 'float64','avg_rt': 'float64','correct_response':'str','response_processing':'str','subblock':'str'})
        example_b = df_Reading_Span["response_processing"].iloc[2]
        df_Reading_Span = df_Reading_Span.replace(example_b,'')
        df_Reading_Span = df_Reading_Span.sort_values(by=['subject_nr'], kind='mergesort')
    else:
        df_Reading_Span = df_Reading_Span[['subject_nr','CB_ref', 'CB_ref_process','practice','TrialNumber', 'subblock', 'SubTaskName', 'acc', 'avg_rt', 'BlockChoice', 'correct', 'correct_response', 'Frase', 'height', 'letter', 'List_Prev_Letter', 'List_responses_memory', 'live_row', 'logfile', 'response_average_time_memory', 'response_memory', 'response_processing', 'response_time_memory', 'response_time_processing', 'response_total_time_memory', 'RP_part_process_time', 'score_practice', 'score_reading_span', 'score_subblock_2_1', 'score_subblock_2_2', 'score_subblock_2_3', 'score_subblock_3_1', 'score_subblock_3_2', 'score_subblock_3_3', 'score_subblock_4_1', 'score_subblock_4_2', 'score_subblock_4_3', 'score_subblock_5_1', 'score_subblock_5_2', 'score_subblock_5_3', 'score_subblock_6_1', 'score_subblock_6_2', 'score_subblock_6_3', 'Sub_bloco', 'Tipo', 'total_correct', 'total_response_time', 'total_responses', 'width']]
        df_Reading_Span[['acc','avg_rt']] = df_Reading_Span[['acc','avg_rt']].replace(',','.')
        df_Reading_Span = df_Reading_Span.astype({'acc': 'float64','avg_rt': 'float64','correct_response':'str','response_processing':'str','subblock':'str'})
        example_b = df_Reading_Span["response_processing"].iloc[2]
        df_Reading_Span = df_Reading_Span.replace(example_b,'')
        df_Reading_Span = df_Reading_Span.sort_values(by=['subject_nr'], kind='mergesort')

if "Sim" in df_total_part['selNB'].values:
    if df_N_Back.iloc[0]['selSocDem'] == "Sim":
        df_N_Back= df_N_Back[['subject_nr','idade','genero','nacionalidade','freqEnsSup','HabEstudante','HabNaoEstudante','AnosEscolaridade','DoencasAnteriores','ListaDoencasAnteriores','CB_ref', 'CB_ref_process','practice', 'TrialNumber', 'average_response_time', 'Block_lenght', 'correct', 'CounterN2BackTrials', 'CounterNonN2BackTrials', 'height', 'letter', 'letter_pos', 'List_Last_N_Pos', 'List_Last_N_Verbal', 'live_row', 'logfile', 'NBackScore', 'RefCalcN2Back', 'RefCalcNonN2Back', 'response', 'response_index_letter', 'response_index_pos', 'response_time', 'rt_correct_n_back','rt_false_alarms', 'SelectCondition', 'TotalCorrectNonTwoBack', 'TotalCorrectTwoBack', 'TotalFalseAlarms', 'TotalMiss', 'width']]
        for i in range(0,len(df_N_Back['average_response_time'])):
            if df_N_Back['average_response_time'].iloc[i] != 'undefined':
                floated_average_response_time = float(df_N_Back['average_response_time'].iloc[i])
                df_N_Back = df_N_Back.replace(df_N_Back['average_response_time'].iloc[i],floated_average_response_time)
        df_N_Back = df_N_Back.sort_values(by=['subject_nr'], kind='mergesort')
    else:
        df_N_Back= df_N_Back[['subject_nr','CB_ref', 'CB_ref_process','practice', 'TrialNumber', 'average_response_time', 'Block_lenght', 'correct', 'CounterN2BackTrials', 'CounterNonN2BackTrials', 'height', 'letter', 'letter_pos', 'List_Last_N_Pos', 'List_Last_N_Verbal', 'live_row', 'logfile', 'NBackScore', 'RefCalcN2Back', 'RefCalcNonN2Back', 'response', 'response_index_letter', 'response_index_pos', 'response_time', 'rt_correct_n_back','rt_false_alarms', 'SelectCondition', 'TotalCorrectNonTwoBack', 'TotalCorrectTwoBack', 'TotalFalseAlarms', 'TotalMiss', 'width']]
        for i in range(0,len(df_N_Back['average_response_time'])):
            if df_N_Back['average_response_time'].iloc[i] != 'undefined':
                floated_average_response_time = float(df_N_Back['average_response_time'].iloc[i])
                df_N_Back = df_N_Back.replace(df_N_Back['average_response_time'].iloc[i],floated_average_response_time)
        df_N_Back = df_N_Back.sort_values(by=['subject_nr'], kind='mergesort')

#'Equations',
if "Sim" in df_total_part['selOS'].values:
    if df_Operation_Span.iloc[0]['selSocDem'] == "Sim":
        df_Operation_Span = df_Operation_Span[['subject_nr','idade','genero','nacionalidade','freqEnsSup','HabEstudante','HabNaoEstudante','AnosEscolaridade','DoencasAnteriores','ListaDoencasAnteriores','CB_ref', 'CB_ref_process','practice', 'TrialNumber', 'subblock', 'SubTaskName', 'acc', 'avg_rt', 'BlockChoice', 'correct', 'correct_response', 'height', 'letter', 'List_Prev_Letter', 'List_responses_memory', 'live_row', 'logfile', 'response_average_time_memory', 'response_memory', 'response_processing', 'response_time_memory', 'response_time_processing', 'response_total_time_memory', 'OP_part_process_time', 'score_practice', 'score_operation_span', 'score_subblock_2_1', 'score_subblock_2_2', 'score_subblock_2_3', 'score_subblock_3_1', 'score_subblock_3_2', 'score_subblock_3_3', 'score_subblock_4_1', 'score_subblock_4_2', 'score_subblock_4_3', 'score_subblock_5_1', 'score_subblock_5_2', 'score_subblock_5_3', 'score_subblock_6_1', 'score_subblock_6_2', 'score_subblock_6_3', 'Sub_bloco', 'Tipo', 'total_correct', 'total_response_time', 'total_responses', 'width']]
        df_Operation_Span[['acc','avg_rt']] = df_Operation_Span[['acc','avg_rt']].replace(',','.')
        df_Operation_Span = df_Operation_Span.astype({'acc': 'float64','avg_rt': 'float64', 'correct_response': 'str','response_processing':'str','subblock':'str'})
        example_c = df_Operation_Span["response_processing"].iloc[2]
        df_Operation_Span = df_Operation_Span.replace(example_c,'')
        df_Operation_Span = df_Operation_Span.sort_values(by=['subject_nr'], kind='mergesort')
    else:
        df_Operation_Span = df_Operation_Span[['subject_nr','CB_ref', 'CB_ref_process','practice', 'TrialNumber', 'subblock', 'SubTaskName', 'acc', 'avg_rt', 'BlockChoice', 'correct', 'correct_response', 'height', 'letter', 'List_Prev_Letter', 'List_responses_memory', 'live_row', 'logfile', 'response_average_time_memory', 'response_memory', 'response_processing', 'response_time_memory', 'response_time_processing', 'response_total_time_memory', 'OP_part_process_time', 'score_practice', 'score_operation_span', 'score_subblock_2_1', 'score_subblock_2_2', 'score_subblock_2_3', 'score_subblock_3_1', 'score_subblock_3_2', 'score_subblock_3_3', 'score_subblock_4_1', 'score_subblock_4_2', 'score_subblock_4_3', 'score_subblock_5_1', 'score_subblock_5_2', 'score_subblock_5_3', 'score_subblock_6_1', 'score_subblock_6_2', 'score_subblock_6_3', 'Sub_bloco', 'Tipo', 'total_correct', 'total_response_time', 'total_responses', 'width']]
        df_Operation_Span[['acc','avg_rt']] = df_Operation_Span[['acc','avg_rt']].replace(',','.')
        df_Operation_Span = df_Operation_Span.astype({'acc': 'float64','avg_rt': 'float64', 'correct_response': 'str','response_processing':'str','subblock':'str'})
        example_c = df_Operation_Span["response_processing"].iloc[2]
        df_Operation_Span = df_Operation_Span.replace(example_c,'')
        df_Operation_Span = df_Operation_Span.sort_values(by=['subject_nr'], kind='mergesort')

if "Sim" in df_total_part['selBT'].values:
    if df_Binding_Task.iloc[0]['selSocDem'] == "Sim":
        df_Binding_Task = df_Binding_Task[['subject_nr','idade','genero','nacionalidade','freqEnsSup','HabEstudante','HabNaoEstudante','AnosEscolaridade','DoencasAnteriores','ListaDoencasAnteriores','CB_ref', 'CB_ref_process','practice', 'TrialNumber', 'acc', 'average_response_time', 'BindingRawScore', 'correct', 'correct_response', 'counter', 'Delay', 'eightsec_accuracy', 'FalseAlarms', 'height', 'Hits', 'live_row', 'logfile', 'match_1s_accuracy', 'match_1s_avg_rt', 'match_8s_accuracy', 'match_8s_avg_rt', 'mismatch_1s_accuracy', 'mismatch_1s_avg_rt', 'mismatch_8s_accuracy', 'mismatch_8s_avg_rt', 'NNonResponses', 'Omissions', 'onesec_accuracy', 'Probe', 'QuinetteAccuracyScore', 'QuinetteProcessingScore', 'response', 'response_time', 'ResponsesGiven', 'Target', 'total_correct', 'total_match_1s_rt', 'total_match_8s_rt', 'total_mismatch_1s_rt', 'total_mismatch_8s_rt', 'total_response_time', 'total_responses', 'width']]
        df_Binding_Task[['acc','average_response_time']] = df_Binding_Task[['acc','average_response_time']].replace(',','.')
        df_Binding_Task = df_Binding_Task.astype({'acc': 'float64','average_response_time': 'float64', 'correct_response': 'str','response':'str'})
        df_Binding_Task = df_Binding_Task.sort_values(by=['subject_nr'], kind='mergesort')
    else:
        df_Binding_Task = df_Binding_Task[['subject_nr','CB_ref', 'CB_ref_process','practice', 'TrialNumber', 'acc', 'average_response_time', 'BindingRawScore', 'correct', 'correct_response', 'counter', 'Delay', 'eightsec_accuracy', 'FalseAlarms', 'height', 'Hits', 'live_row', 'logfile', 'match_1s_accuracy', 'match_1s_avg_rt', 'match_8s_accuracy', 'match_8s_avg_rt', 'mismatch_1s_accuracy', 'mismatch_1s_avg_rt', 'mismatch_8s_accuracy', 'mismatch_8s_avg_rt', 'NNonResponses', 'Omissions', 'onesec_accuracy', 'Probe', 'QuinetteAccuracyScore', 'QuinetteProcessingScore', 'response', 'response_time', 'ResponsesGiven', 'Target', 'total_correct', 'total_match_1s_rt', 'total_match_8s_rt', 'total_mismatch_1s_rt', 'total_mismatch_8s_rt', 'total_response_time', 'total_responses', 'width']]
        df_Binding_Task[['acc','average_response_time']] = df_Binding_Task[['acc','average_response_time']].replace(',','.')
        df_Binding_Task = df_Binding_Task.astype({'acc': 'float64','average_response_time': 'float64', 'correct_response': 'str','response':'str'})
        df_Binding_Task = df_Binding_Task.sort_values(by=['subject_nr'], kind='mergesort')

if "Sim" in df_total_part['selMS'].values:
    if df_Multimodal_Span.iloc[0]['selSocDem'] == "Sim":
        df_Multimodal_Span = df_Multimodal_Span[['subject_nr','idade','genero','nacionalidade','freqEnsSup','HabEstudante','HabNaoEstudante','AnosEscolaridade','DoencasAnteriores','ListaDoencasAnteriores','CB_ref', 'CB_ref_process','practice', 'TrialNumber', 'keep_track_seq_lenght', 'acc', 'average_response_time_Multimodal', 'calculate_score', 'correct_response', 'height', 'keep_track_errors', 'List_keys_pressed', 'List_Multimodal_button', 'List_Multimodal_Letter', 'List_Multimodal_Pos', 'live_row', 'logfile', 'MultimodalSpanScore', 'pressed_buttons', 'response_time_Multimodal', 'total_correct', 'width']]
        df_Multimodal_Span = df_Multimodal_Span.rename(columns={'correct_response': 'correct'})
        df_Multimodal_Span['acc'] = df_Multimodal_Span['acc'].replace(',','.')
        df_Multimodal_Span = df_Multimodal_Span.astype({'acc': 'float64','correct': 'float64'})
        df_Multimodal_Span = df_Multimodal_Span.sort_values(by=['subject_nr'], kind='mergesort')
    else:
        df_Multimodal_Span = df_Multimodal_Span[['subject_nr','CB_ref', 'CB_ref_process','practice', 'TrialNumber', 'keep_track_seq_lenght', 'acc', 'average_response_time_Multimodal', 'calculate_score', 'correct_response', 'height', 'keep_track_errors', 'List_keys_pressed', 'List_Multimodal_button', 'List_Multimodal_Letter', 'List_Multimodal_Pos', 'live_row', 'logfile', 'MultimodalSpanScore', 'pressed_buttons', 'response_time_Multimodal', 'total_correct', 'width']]
        df_Multimodal_Span = df_Multimodal_Span.rename(columns={'correct_response': 'correct'})
        df_Multimodal_Span['acc'] = df_Multimodal_Span['acc'].replace(',','.')
        df_Multimodal_Span = df_Multimodal_Span.astype({'acc': 'float64','correct': 'float64'})
        df_Multimodal_Span = df_Multimodal_Span.sort_values(by=['subject_nr'], kind='mergesort')

if "Sim" in df_total_part['selSS'].values:
    if df_Symmetry_Span.iloc[0]['selSocDem'] == "Sim":
        df_Symmetry_Span = df_Symmetry_Span[['subject_nr','idade','genero','nacionalidade','freqEnsSup','HabEstudante','HabNaoEstudante','AnosEscolaridade','DoencasAnteriores','ListaDoencasAnteriores','CB_ref', 'CB_ref_process','practice','TrialNumber', 'subblock', 'SubTaskName', 'aggregated_score_memory', 'average_response_time_processing', 'average_total_time_memory', 'correct', 'correct_response', 'countDys','countSym', 'height', 'LeftHalfPos', 'List_SS_button', 'List_SS_Pos', 'live_row', 'logfile', 'maxDys', 'maxSym', 'pressed_buttons', 'response_memory', 'response_processing', 'response_time_memory', 'response_time_processing', 'response_total_time_memory', 'response_total_time_memory_full_task', 'RightHalfPos', 'SP_part_process_time', 'SS_practice_score', 'score_symmetry_span', 'score_subblock_2_1', 'score_subblock_2_2', 'score_subblock_2_3', 'score_subblock_3_1', 'score_subblock_3_2', 'score_subblock_3_3', 'score_subblock_4_1', 'score_subblock_4_2', 'score_subblock_4_3', 'score_subblock_5_1', 'score_subblock_5_2', 'score_subblock_5_3', 'score_subblock_6_1', 'score_subblock_6_2', 'score_subblock_6_3', 'Sub_bloco', 'SymType', 'total_correct_processing', 'total_response_time_processing', 'width']]
        df_Symmetry_Span = df_Symmetry_Span.astype({'correct_response':'str','response_processing':'str','subblock':'str'})
        example_d = df_Symmetry_Span["response_processing"].iloc[2]
        df_Symmetry_Span = df_Symmetry_Span.replace(example_d,'')
        df_Symmetry_Span = df_Symmetry_Span.sort_values(by=['subject_nr'], kind='mergesort')
    else:
        df_Symmetry_Span = df_Symmetry_Span[['subject_nr','CB_ref', 'CB_ref_process','practice','TrialNumber', 'subblock', 'SubTaskName', 'aggregated_score_memory', 'average_response_time_processing', 'average_total_time_memory', 'correct', 'correct_response', 'countDys','countSym', 'height', 'LeftHalfPos', 'List_SS_button', 'List_SS_Pos', 'live_row', 'logfile', 'maxDys', 'maxSym', 'pressed_buttons', 'response_memory', 'response_processing', 'response_time_memory', 'response_time_processing', 'response_total_time_memory', 'response_total_time_memory_full_task', 'RightHalfPos', 'SP_part_process_time', 'SS_practice_score', 'score_symmetry_span', 'score_subblock_2_1', 'score_subblock_2_2', 'score_subblock_2_3', 'score_subblock_3_1', 'score_subblock_3_2', 'score_subblock_3_3', 'score_subblock_4_1', 'score_subblock_4_2', 'score_subblock_4_3', 'score_subblock_5_1', 'score_subblock_5_2', 'score_subblock_5_3', 'score_subblock_6_1', 'score_subblock_6_2', 'score_subblock_6_3', 'Sub_bloco', 'SymType', 'total_correct_processing', 'total_response_time_processing', 'width']]
        df_Symmetry_Span = df_Symmetry_Span.astype({'correct_response':'str','response_processing':'str','subblock':'str'})
        example_d = df_Symmetry_Span["response_processing"].iloc[2]
        df_Symmetry_Span = df_Symmetry_Span.replace(example_d,'')
        df_Symmetry_Span = df_Symmetry_Span.sort_values(by=['subject_nr'], kind='mergesort')

if "Sim" in df_total_part['selUT'].values:
    if df_WMU_Task.iloc[0]['selSocDem'] == "Sim":
        df_WMU_Task = df_WMU_Task[['subject_nr','idade','genero','nacionalidade','freqEnsSup','HabEstudante','HabNaoEstudante','DoencasAnteriores','AnosEscolaridade','ListaDoencasAnteriores','CB_ref', 'CB_ref_process','practice','TrialNumber','correct1','correct2','correct3','correct_response1','correct_response2','correct_response3','digit1','digit2','digit3','height', 'Index_List','live_row', 'logfile','response1','response2','response3','response_time1','responseavgRT','total_correct_trial','TotalRtBlock','toUpdate1_1','toUpdate1_2','toUpdate1_3','toUpdate2_1','toUpdate2_2','toUpdate2_3','WMUExperimentalScore','WMUPracticeScore','width']]
        df_WMU_Task = df_WMU_Task.rename(columns={'response_time1':'response_time'})
        df_WMU_Task = df_WMU_Task.sort_values(by=['subject_nr'], kind='mergesort')
        for i in range(0,len(df_WMU_Task['responseavgRT'])):
            if df_WMU_Task['responseavgRT'].iloc[i] == 0:
                df_WMU_Task['responseavgRT'].iloc[i] = ''
        WMU_cast_lis = ['toUpdate1_1','toUpdate1_2','toUpdate1_3','toUpdate2_1','toUpdate2_2','toUpdate2_3']
        for i in WMU_cast_lis:
            for j in range(0,len(df_WMU_Task[i])):
                if df_WMU_Task[i].iloc[j] > 0:
                    df_WMU_Task[i].iloc[j] = '+' + str(int(df_WMU_Task[i].iloc[j]))
                else:
                    df_WMU_Task[i].iloc[j] = str(int(df_WMU_Task[i].iloc[j]))
    else:
        df_WMU_Task = df_WMU_Task[['subject_nr','CB_ref', 'CB_ref_process','practice','TrialNumber','correct1','correct2','correct3','correct_response1','correct_response2','correct_response3','digit1','digit2','digit3','height', 'Index_List','live_row', 'logfile','response1','response2','response3','response_time1','responseavgRT','total_correct_trial','TotalRtBlock','toUpdate1_1','toUpdate1_2','toUpdate1_3','toUpdate2_1','toUpdate2_2','toUpdate2_3','WMUExperimentalScore','WMUPracticeScore','width']]
        df_WMU_Task = df_WMU_Task.rename(columns={'response_time1':'response_time'})
        df_WMU_Task = df_WMU_Task.sort_values(by=['subject_nr'], kind='mergesort')
        for i in range(0,len(df_WMU_Task['responseavgRT'])):
            if df_WMU_Task['responseavgRT'].iloc[i] == 0:
                df_WMU_Task['responseavgRT'].iloc[i] = ''
        WMU_cast_lis = ['toUpdate1_1','toUpdate1_2','toUpdate1_3','toUpdate2_1','toUpdate2_2','toUpdate2_3']
        for i in WMU_cast_lis:
            for j in range(0,len(df_WMU_Task[i])):
                if df_WMU_Task[i].iloc[j] > 0:
                    df_WMU_Task[i].iloc[j] = '+' + str(int(df_WMU_Task[i].iloc[j]))
                else:
                    df_WMU_Task[i].iloc[j] = str(int(df_WMU_Task[i].iloc[j]))

########################################################################################################################################
###Criação das Df que irão conter os Raw Scores e os scores convertidos dos participantes, bem como a estatísitcas descritivas.
###Criação da folha de excel com os Raw Scores
df_raw_scores = pd.DataFrame()

###Criação das labels para as colunas da data frame.
if "Sim" in df_total_part['selRS'].values:
    labRS = "Reading Span"
else:
    labRS = float("nan")

if "Sim" in df_total_part['selUT'].values:
    labUT = "Updating Task"
else:
    labUT = float("nan")

if "Sim" in df_total_part['selBT'].values:
    labBT = "Binding Task"
else:
    labBT = float("nan")

if "Sim" in df_total_part['selOS'].values:
    labOS = "Operation Span"
else:
    labOS = float("nan")

if "Sim" in df_total_part['selNB'].values:
    labNB= "N-Back Task"
else:
    labNB = float("nan")

if "Sim" in df_total_part['selMS'].values:
    labMS = "Multimodal Span"
else:
    labMS = float("nan")

if "Sim" in df_total_part['selSS'].values:
    labSS = "Symmetry Span"
else:
    labSS = float("nan")

##Criação das colunas na dataframe df_raw_scores.
colnames = [labRS,labUT,labBT,labOS,labNB,labMS,labSS]
for i in colnames:
    df_raw_scores[i] = float("nan")
#if "Não" in df_total_part['selRS'].values or "Não" in df_total_part['selUT'].values or "Não" in df_total_part['selBT'].values or "Não" in df_total_part['selOS'].values or "Não" in df_total_part['selNB'].values or "Não" in df_total_part['selMS'].values or "Não" in df_total_part['selSS'].values:
if "Nan" in df_raw_scores.columns:
    df_raw_scores.columns = df_raw_scores.columns.fillna('to_drop')
    df_raw_scores.drop('to_drop', axis = 1, inplace = True)
subj_nr = df_total_part["subject_nr"].unique()
df_raw_scores.insert(0,'subject_nr',subj_nr)

###Inserção dos valores obtidos por cada participante em cada uma das provas em que realizaram (e dos dados socio-demografcos)
##na data frame df_raw_scores.
if "Sim" in df_total_part['selRS'].values:
    RawRS = list((df_Reading_Span.groupby(['subject_nr'],sort=True)['score_reading_span'].max()*60))
    df_raw_scores["Reading Span"] = RawRS
if "Sim" in df_total_part['selUT'].values:
    RawUT = list(df_WMU_Task.groupby(['subject_nr'],sort=True)['WMUExperimentalScore'].max())
    df_raw_scores["Updating Task"] = RawUT
if "Sim" in df_total_part['selBT'].values:
    RawBT = list(df_Binding_Task.groupby(['subject_nr'],sort=True)['BindingRawScore'].max())
    df_raw_scores["Binding Task"] = RawBT
if "Sim" in df_total_part['selOS'].values:
    RawOS = list((df_Operation_Span.groupby(['subject_nr'],sort=True)['score_operation_span'].max()*60))
    df_raw_scores["Operation Span"] = RawOS
if "Sim" in df_total_part['selNB'].values:
    RawNB = list(df_N_Back.groupby(['subject_nr'],sort=True)['TotalCorrectTwoBack'].max())
    df_raw_scores["N-Back Task"] = RawNB
if "Sim" in df_total_part['selMS'].values:
    RawMS = list(df_Multimodal_Span.groupby(['subject_nr'],sort=True)['MultimodalSpanScore'].max())
    df_raw_scores["Multimodal Span"] = RawMS
if "Sim" in df_total_part['selSS'].values:
    RawSS = list((df_Symmetry_Span.groupby(['subject_nr'],sort=True)['score_symmetry_span'].max()*60))
    df_raw_scores["Symmetry Span"] = RawSS
if "Sim" in df_total_part['selSocDem'].values:
    IdadeList = list(df_total_part.groupby(['subject_nr'],sort=True)['idade'].unique())
    for i in (0,len(IdadeList)-1):
        IdadeList[i] = int(IdadeList[0])
    df_raw_scores.insert(1, 'Idade', IdadeList)
    generoList = list(df_total_part.groupby(['subject_nr'],sort=True)['genero'].unique())
    for i in (0,len(generoList)-1):
        generoList[i] = str(generoList[0])
        generoList[i] = generoList[i][1:len(generoList[i])-1]
    df_raw_scores.insert(2, 'Género', generoList)
    nacionalidadeList = list(df_total_part.groupby(['subject_nr'],sort=True)['nacionalidade'].unique())
    for i in (0,len(nacionalidadeList)-1):
        nacionalidadeList[i] = str(nacionalidadeList[0])
        nacionalidadeList[i] = nacionalidadeList[i][1:len(nacionalidadeList[i])-1]
    df_raw_scores.insert(3, 'Nacionalidade', nacionalidadeList)
    freqEnsSupList = list(df_total_part.groupby(['subject_nr'],sort=True)['freqEnsSup'].unique())
    for i in (0,len(freqEnsSupList)-1):
        freqEnsSupList[i] = str(freqEnsSupList[0])
        freqEnsSupList[i] = freqEnsSupList[i][1:len(freqEnsSupList[i])-1]
    df_raw_scores.insert(4, 'FreqEnsSup', freqEnsSupList)
    HabEstudanteList = list(df_total_part.groupby(['subject_nr'],sort=True)['HabEstudante'].unique())
    for i in (0,len(HabEstudanteList)-1):
        HabEstudanteList[i] = str(HabEstudanteList[0])
        HabEstudanteList[i] = HabEstudanteList[i][1:len(HabEstudanteList[i])-1]
    df_raw_scores.insert(5, 'HabEstudante', HabEstudanteList)
    HabNaoEstudanteList = list(df_total_part.groupby(['subject_nr'],sort=True)['HabNaoEstudante'].unique())
    for i in (0,len(HabNaoEstudanteList)-1):
        HabNaoEstudanteList[i] = str(HabNaoEstudanteList[0])
        HabNaoEstudanteList[i] = HabNaoEstudanteList[i][1:len(HabNaoEstudanteList[i])-1]
    df_raw_scores.insert(6, 'HabNaoEstudante', HabNaoEstudanteList)
    AnosEscolaridadeList = list(df_total_part.groupby(['subject_nr'],sort=True)['AnosEscolaridade'].unique())
    for i in (0,len(AnosEscolaridadeList)-1):
        AnosEscolaridadeList[i] = int(AnosEscolaridadeList[0])
    df_raw_scores.insert(7, 'AnosEscolaridade', AnosEscolaridadeList)
    DoencasAnterioresList = list(df_total_part.groupby(['subject_nr'],sort=True)['DoencasAnteriores'].unique())
    for i in (0,len(DoencasAnterioresList)-1):
        DoencasAnterioresList[i] = str(DoencasAnterioresList[0])
        DoencasAnterioresList[i] = DoencasAnterioresList[i][1:len(DoencasAnterioresList[i]) - 1]
    df_raw_scores.insert(8, 'DoencasAnteriores', DoencasAnterioresList)
    ListaDoencasAnterioresList = list(df_total_part.groupby(['subject_nr'],sort=True)['ListaDoencasAnteriores'].unique())
    for i in (0,len(ListaDoencasAnterioresList)-1):
        ListaDoencasAnterioresList[i] = str(ListaDoencasAnterioresList[0])
        ListaDoencasAnterioresList[i] = ListaDoencasAnterioresList[i][1:len(ListaDoencasAnterioresList[i]) - 1]
    df_raw_scores.insert(9, 'ListaDoencasAnteriores', ListaDoencasAnterioresList)

########################################################################################################################################
######Criação da DataFrame com os valores normalizados obtidos por cada participante em cada uma das provas em que realizaram (e com os
#####dados socio-demografcos).
df_normalized_scores = df_raw_scores.copy(deep=True)

if "Sim" in df_total_part['selRS'].values:
    df_normalized_scores["Reading Span"] = df_normalized_scores["Reading Span"]/60
if "Sim" in df_total_part['selUT'].values:
    df_normalized_scores["Updating Task"] = df_normalized_scores["Updating Task"] / 36
if "Sim" in df_total_part['selBT'].values:
    df_normalized_scores["Binding Task"] = df_normalized_scores["Binding Task"] / 16
if "Sim" in df_total_part['selOS'].values:
    df_normalized_scores["Operation Span"] = df_normalized_scores["Operation Span"] / 60
if "Sim" in df_total_part['selNB'].values:
    df_normalized_scores["N-Back Task"] = df_normalized_scores["N-Back Task"] / 12
if "Sim" in df_total_part['selMS'].values:
    df_normalized_scores["Multimodal Span"] = df_normalized_scores["Multimodal Span"] / 11
if "Sim" in df_total_part['selSS'].values:
    df_normalized_scores["Symmetry Span"] = df_normalized_scores["Symmetry Span"] / 60

########################################################################################################################################
###Criação das dataframes com as estatísticas descritivas dos raw scores e dos dados normalizados.
descrNormalized = df_normalized_scores.describe()
descrNormalized.drop(["subject_nr"],axis=1,inplace=True)

descrRaw = df_raw_scores.describe()
descrRaw.drop(["subject_nr"],axis=1,inplace=True)

###Guarda as  DataFrames criadas ao longo deste script num só ficheiro de excel que contém diferentes excel_sheets com informações
###relacionadas com as  tarefas de memória de trabalho realizadas pelos participantes. Para além disso, cria ainda folhas de excel
###com os raw scores e os normalized scores obtidos pelos participantes, e folhas de excel com as estatísticas descritivas dos raw
###scores e dos normalized scores.
with pd.ExcelWriter('BD_WM_Battery.xlsx') as writer:
    if "Sim" in df_total_part['selRS'].values:
        df_Reading_Span.to_excel(writer, sheet_name='Reading Span', index=False)
    if "Sim" in df_total_part['selUT'].values:
        df_WMU_Task.to_excel(writer, sheet_name='Updating Task', index=False)
    if "Sim" in df_total_part['selBT'].values:
        df_Binding_Task.to_excel(writer, sheet_name='Binding Task', index=False)
    if "Sim" in df_total_part['selOS'].values:
        df_Operation_Span.to_excel(writer, sheet_name='Operation Span', index=False)
    if "Sim" in df_total_part['selNB'].values:
        df_N_Back.to_excel(writer, sheet_name='N-Back Task', index=False)
    if "Sim" in df_total_part['selMS'].values:
        df_Multimodal_Span.to_excel(writer, sheet_name='Multimodal Span', index=False)
    if "Sim" in df_total_part['selSS'].values:
        df_Symmetry_Span.to_excel(writer, sheet_name='Symmetry Span', index=False)
    df_raw_scores.to_excel(writer,sheet_name='Raw Scores', index=False)
    df_normalized_scores.to_excel(writer, sheet_name='Normalized Scores', index=False)
    descrRaw.to_excel(writer,sheet_name='Raw Descriptive',index=True)
    descrNormalized.to_excel(writer,sheet_name='Normalized Descriptive',index=True)